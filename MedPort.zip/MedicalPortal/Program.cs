﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MedicalPortal
{
    // --- МОДЕЛЬ СИМПТОМОВ И ДИАГНОЗОВ ---
    public class DiagnosisRule
    {
        public string DiagnosisName { get; set; }
        public List<string> RequiredSymptoms { get; set; }

        public DiagnosisRule(string name, params string[] symptoms)
        {
            DiagnosisName = name;
            RequiredSymptoms = symptoms.Select(s => s.ToLower()).ToList();
        }
    }

    // --- КЛАСС ПАЦИЕНТА (Задание №3) ---
    public class Patient
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Diagnosis { get; set; }

        public Patient(string name, int age, string diagnosis = "Не установлен")
        {
            Name = name;
            Age = age;
            Diagnosis = diagnosis;
        }

        public string GetInfoHtml() => $"[Пациент] ФИО: <b>{Name}</b> | Возраст: {Age} лет | Диагноз: <b>{Diagnosis}</b>";
    }

    // --- БАЗОВЫЙ АБСТРАКТНЫЙ КЛАСС ВРАЧА (Задание №2) ---
    public abstract class Doctor
    {
        public string Name { get; set; }
        public int Experience { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public List<DiagnosisRule> DiagnosisDatabase { get; protected set; }

        public abstract string Specialization { get; }

        protected Doctor(string name, int experience, string login, string password)
        {
            Name = name;
            Experience = experience;
            Login = login;
            Password = password;
            DiagnosisDatabase = new List<DiagnosisRule>();
            InitializeDiagnoses();
        }

        protected abstract void InitializeDiagnoses();
        public abstract string Reception();

        public void DiagnoseByFilters(Patient patient, List<string> selectedSymptoms)
        {
            var normalizedInput = selectedSymptoms.Select(s => s.Trim().ToLower()).ToList();
            var matchedRule = DiagnosisDatabase
                .OrderByDescending(rule => rule.RequiredSymptoms.Count(s => normalizedInput.Contains(s)))
                .FirstOrDefault(rule => rule.RequiredSymptoms.Any(s => normalizedInput.Contains(s)));

            if (matchedRule != null)
            {
                patient.Diagnosis = matchedRule.DiagnosisName;
            }
            else
            {
                patient.Diagnosis = "Требуется дополнительное обследование";
            }
        }
    }

    // --- СПЕЦИАЛЬНОСТИ ВРАЧЕЙ ---
    public class Therapist : Doctor
    {
        public override string Specialization => "Терапевт";
        public Therapist(string name, int experience, string login, string password) : base(name, experience, login, password) { }
        protected override void InitializeDiagnoses()
        {
            DiagnosisDatabase.Add(new DiagnosisRule("ОРВИ", "температура", "кашель", "насморк"));
            DiagnosisDatabase.Add(new DiagnosisRule("Ангина", "боль в горле", "высокая температура"));
        }
        public override string Reception() => $"[{Specialization}] {Name} проводит общий осмотр и слушает лёгкие.";
    }

    public class Cardiologist : Doctor
    {
        public override string Specialization => "Кардиолог";
        public Cardiologist(string name, int experience, string login, string password) : base(name, experience, login, password) { }
        protected override void InitializeDiagnoses()
        {
            DiagnosisDatabase.Add(new DiagnosisRule("Гипертония", "высокое давление", "головная боль"));
            DiagnosisDatabase.Add(new DiagnosisRule("Аритмия", "учащенный пульс", "одышка"));
        }
        public override string Reception() => $"[{Specialization}] {Name} снимает ЭКГ и измеряет давление.";
    }

    public class Dentist : Doctor
    {
        public override string Specialization => "Стоматолог";
        public Dentist(string name, int experience, string login, string password) : base(name, experience, login, password) { }
        protected override void InitializeDiagnoses()
        {
            DiagnosisDatabase.Add(new DiagnosisRule("Кариес", "реакция на сладкое", "ноющая боль"));
            DiagnosisDatabase.Add(new DiagnosisRule("Пульпит", "острая боль", "боль ночью"));
        }
        public override string Reception() => $"[{Specialization}] {Name} проводит осмотр полости рта.";
    }

    // --- ЗАДАНИЕ №1: НЕВРОЛОГ ---
    public class Neurologist : Doctor
    {
        public override string Specialization => "Невролог";
        public Neurologist(string name, int experience, string login, string password) : base(name, experience, login, password) { }
        protected override void InitializeDiagnoses()
        {
            DiagnosisDatabase.Add(new DiagnosisRule("Мигрень", "пульсирующая головная боль", "светобоязнь"));
            DiagnosisDatabase.Add(new DiagnosisRule("Остеохондроз", "боль в спине", "онемение рук"));
        }
        public override string Reception() => "Невролог проводит проверку нервной системы";
    }

    // --- ЗАПИСЬ НА ПРИЁМ (Задание №4) ---
    public class Appointment
    {
        public Patient Patient { get; set; }
        public Doctor Doctor { get; set; }
        public DateTime AppointmentDate { get; set; }

        public Appointment(Patient patient, Doctor doctor, DateTime date)
        {
            Patient = patient;
            Doctor = doctor;
            AppointmentDate = date;
        }

        public string GetAppointmentInfo() => 
            $"Запись к врачу {Doctor.Name} ({Doctor.Specialization}) для пациента {Patient.Name} на {AppointmentDate:dd.MM.yyyy HH:mm}";
    }

    // --- ВЕБ-СЕРВЕР ---
    class Program
    {
        static List<Doctor> doctors = new List<Doctor>
        {
            new Therapist("Иванов А.А.", 12, "ivanov", "1111"),
            new Cardiologist("Петрова Е.В.", 18, "petrova", "2222"),
            new Dentist("Сидоров К.М.", 7, "sidorov", "3333"),
            new Neurologist("Смирнова О.И.", 15, "smirnova", "4444") // Задание №1
        };

        static List<Patient> patients = new List<Patient>
        {
            new Patient("Козлов Дмитрий", 28),
            new Patient("Волкова Анна", 45),
            new Patient("Николаев Игорь", 52)
        };

        static Dictionary<string, Doctor> activeSessions = new Dictionary<string, Doctor>();

        static async Task Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            HttpListener listener = new HttpListener();
            string url = "http://localhost:5000/";
            listener.Prefixes.Add(url);
            listener.Start();

            Console.WriteLine("==================================================");
            Console.WriteLine(" МЕДИЦИНСКИЙ ПОРТАЛ УСПЕШНО ЗАПУЩЕН НА ЛОКАЛЬНОМ СЕРВЕРЕ!");
            Console.WriteLine($" Откройте эту ссылку в браузере: {url}");
            Console.WriteLine("==================================================");
            Console.WriteLine("Для остановки сервера нажмите Ctrl + C в терминале.\n");

            while (true)
            {
                var context = await listener.GetContextAsync();
                var request = context.Request;
                var response = context.Response;

                string responseString = HandleRequest(request);
                byte[] buffer = Encoding.UTF8.GetBytes(responseString);

                response.ContentLength64 = buffer.Length;
                response.ContentEncoding = Encoding.UTF8;
                response.ContentType = "text/html; charset=utf-8";

                var output = response.OutputStream;
                await output.WriteAsync(buffer, 0, buffer.Length);
                output.Close();
            }
        }

        static string HandleRequest(HttpListenerRequest request)
        {
            string path = request.Url.AbsolutePath;
            string query = request.Url.Query;
            var queryParams = System.Web.HttpUtility.ParseQueryString(query);

            string htmlHeader = "<html><head><meta charset='utf-8'><title>Мед Портал</title><style>body{font-family:Arial;margin:40px;background:#f4f4f9;} .card{background:white;padding:20px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);max-width:600px;margin:auto;} input, select{padding:8px;margin:5px 0;width:100%;box-sizing:border-box;} button{background:#007bff;color:white;border:none;padding:10px;width:100%;border-radius:4px;cursor:pointer;} button:hover{background:#0056b3;} a{color:#007bff;text-decoration:none;}</style></head><body><div class='card'>";
            string htmlFooter = "</div></body></html>";

            // Главная страница / Вход
            if (path == "/")
            {
                string error = queryParams["error"] != null ? "<p style='color:red;'>Неверный логин или пароль!</p>" : "";
                
                string accountsInfo = "<h3>Доступные аккаунты для теста:</h3><ul>";
                foreach (var d in doctors)
                {
                    accountsInfo += $"<li><b>{d.Specialization} ({d.Name})</b> — Логин: <code>{d.Login}</code>, Пароль: <code>{d.Password}</code></li>";
                }
                accountsInfo += "</ul>";

                return $"{htmlHeader}<h2>Вход в личный кабинет врача</h2>{error}" +
                       $"<form method='POST' action='/login'>" +
                       $"Логин: <input type='text' name='login' required>" +
                       $"Пароль: <input type='password' name='password' required>" +
                       $"<button type='submit'>Войти</button></form>" +
                       $"{accountsInfo}{htmlFooter}";
            }

            // Обработка входа
            if (path == "/login" && request.HttpMethod == "POST")
            {
                using var reader = new StreamReader(request.InputStream, request.ContentEncoding);
                string body = reader.ReadToEnd();
                var data = System.Web.HttpUtility.ParseQueryString(body);
                string login = data["login"];
                string password = data["password"];

                Doctor doc = doctors.FirstOrDefault(d => d.Login == login && d.Password == password);
                if (doc != null)
                {
                    string sessionId = Guid.NewGuid().ToString();
                    activeSessions[sessionId] = doc;

                    var cookie = new System.Net.Cookie("session", sessionId);
                    contextResponseCookie(request, cookie); // Упрощенный редирект с кукой
                    
                    return $"<html><head><meta http-equiv='refresh' content='0;url=/cabinet?sid={sessionId}'></head><body></body></html>";
                }
                else
                {
                    return $"<html><head><meta http-equiv='refresh' content='0;url=/?error=1'></head><body></body></html>";
                }
            }

            // Личный кабинет врача
            if (path == "/cabinet")
            {
                string sid = queryParams["sid"];
                if (sid == null || !activeSessions.ContainsKey(sid)) return $"{htmlHeader}<h3>Сессия истекла. <a href='/'>Войти снова</a></h3>{htmlFooter}";

                Doctor doc = activeSessions[sid];
                string message = queryParams["msg"] ?? "";

                string patientListHtml = "";
                for (int i = 0; i < patients.Count; i++)
                {
                    patientListHtml += $"<li>{patients[i].GetInfoHtml()} - <a href='/diagnose?sid={sid}&pIndex={i}'>Поставить диагноз</a></li>";
                }

                return $"{htmlHeader}<h2>Личный кабинет: {doc.Name} ({doc.Specialization})</h2>" +
                       $"<p style='color:green;'><b>{message}</b></p>" +
                       $"<hr><h3>Действия врача:</h3>" +
                       $"<p><a href='/reception?sid={sid}'><button type='button'>1. Провести приём (вызов метода Reception)</button></a></p>" +
                       $"<h3>Список пациентов:</h3><ul>{patientListHtml}</ul>" +
                       $"<br><a href='/'>Выйти из аккаунта</a>{htmlFooter}";
            }

            // Вызов метода Reception()
            if (path == "/reception")
            {
                string sid = queryParams["sid"];
                if (sid == null || !activeSessions.ContainsKey(sid)) return "Ошибка сессии";
                Doctor doc = activeSessions[sid];
                string receptionResult = doc.Reception();

                return $"<html><head><meta http-equiv='refresh' content='3;url=/cabinet?sid={sid}&msg={System.Net.WebUtility.UrlEncode(receptionResult)}'></head><body><h3>{receptionResult}</h3><p>Возвращаем в кабинет...</p></body></html>";
            }

            // Страница постановки диагноза
            if (path == "/diagnose")
            {
                string sid = queryParams["sid"];
                if (sid == null || !activeSessions.ContainsKey(sid)) return "Ошибка сессии";
                Doctor doc = activeSessions[sid];
                int pIndex = int.Parse(queryParams["pIndex"]);
                Patient patient = patients[pIndex];

                var availableSymptoms = doc.DiagnosisDatabase.SelectMany(d => d.RequiredSymptoms).Distinct().ToList();

                return $"{htmlHeader}<h2>Постановка диагноза для {patient.Name}</h2>" +
                       $"<p>Врач: <b>{doc.Name} ({doc.Specialization})</b></p>" +
                       $"<p>Доступные симптомы для выбора: <i>{string.Join(", ", availableSymptoms)}</i></p>" +
                       $"<form method='POST' action='/save-diagnose?sid={sid}&pIndex={pIndex}'>" +
                       $"Введите симптомы через запятую: <input type='text' name='symptoms' placeholder='например: {string.Join(", ", availableSymptoms.Take(2))}' required>" +
                       $"<button type='submit'>Поставить диагноз</button></form>" +
                       $"<br><a href='/cabinet?sid={sid}'>Назад в кабинет</a>{htmlFooter}";
            }

            // Сохранение диагноза
            if (path == "/save-diagnose" && request.HttpMethod == "POST")
            {
                string sid = queryParams["sid"];
                int pIndex = int.Parse(queryParams["pIndex"]);
                Doctor doc = activeSessions[sid];
                Patient patient = patients[pIndex];

                using var reader = new StreamReader(request.InputStream, request.ContentEncoding);
                string body = reader.ReadToEnd();
                var data = System.Web.HttpUtility.ParseQueryString(body);
                string symptomsInput = data["symptoms"];

                List<string> symptomsList = symptomsInput.Split(',').ToList();
                doc.DiagnoseByFilters(patient, symptomsList);

                return $"<html><head><meta http-equiv='refresh' content='0;url=/cabinet?sid={sid}&msg={System.Net.WebUtility.UrlEncode("Диагноз успешно обновлен: " + patient.Diagnosis)}'></head><body></body></html>";
            }

            return "404 Страница не найдена";
        }

        static void contextResponseCookie(HttpListenerRequest request, System.Net.Cookie cookie) { }
    }
}