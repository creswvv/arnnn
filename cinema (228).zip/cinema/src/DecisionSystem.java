
public class DecisionSystem {

    Cinema cinema = new Cinema();

    public void makeDecision(int choice) {

        switch (choice) {

            case 1:
                cinema.showMovies();
                break;

            case 2:
                cinema.buyTicket();
                break;

            case 3:
                cinema.showPrice();
                break;

            case 0:
                System.out.println("Thank you! Goodbye!");
                break;

            default:
                System.out.println("Wrong choice!");
        }
    }
}
