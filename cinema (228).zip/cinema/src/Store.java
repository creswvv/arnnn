import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Store {

    private final Path file = Paths.get("data", "posts.txt");

    public Store() {
        try {
            Files.createDirectories(file.getParent());
            if (!Files.exists(file)) Files.createFile(file);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static String enc(String s) {
        return URLEncoder.encode(s == null ? "" : s, StandardCharsets.UTF_8);
    }

    private static String dec(String s) {
        return URLDecoder.decode(s, StandardCharsets.UTF_8);
    }

    public synchronized List<Post> all() {
        List<Post> list = new ArrayList<>();
        try {
            for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
                if (line.isBlank()) continue;
                String[] p = line.split("\t", -1);
                if (p.length < 7) continue;
                list.add(new Post(dec(p[0]), dec(p[1]), dec(p[2]), dec(p[3]),
                        dec(p[4]), dec(p[5]), Long.parseLong(p[6])));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        list.sort(Comparator.comparingLong(Post::created).reversed());
        return list;
    }

    private void save(List<Post> list) {
        List<String> lines = new ArrayList<>();
        for (Post p : list) {
            lines.add(String.join("\t", enc(p.id()), enc(p.kind()), enc(p.title()),
                    enc(p.text()), enc(p.media()), enc(p.mediaType()),
                    String.valueOf(p.created())));
        }
        try {
            Files.write(file, lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public synchronized void add(Post post) {
        List<Post> list = all();
        list.add(post);
        save(list);
    }

    public synchronized Post delete(String id) {
        List<Post> list = all();
        Post removed = null;
        for (Post p : list) {
            if (p.id().equals(id)) {
                removed = p;
                break;
            }
        }
        if (removed != null) {
            list.remove(removed);
            save(list);
        }
        return removed;
    }
}