import java.util.Scanner;

public class Cinema {

    Scanner scanner = new Scanner(System.in);

    String[] movies = {
            "Avatar 2",
            "Interstellar",
            "Spider-Man",
            "Fast and Furious 10"
    };

    int price = 2000;

    public String[] getMovies() {
        return movies;
    }

    public int getPrice() {
        return price;
    }

    public void showMovies() {
        System.out.println("\n===== MOVIES =====");
        for (int i = 0; i < movies.length; i++) {
            System.out.println((i + 1) + ". " + movies[i]);
        }
    }

    public void showPrice() {
        System.out.println("Ticket price: " + price + " KZT");
    }

    public void buyTicket() {
        showMovies();
        System.out.print("Choose movie number: ");
        int choice = scanner.nextInt();

        if (choice < 1 || choice > movies.length) {
            System.out.println("Movie not found!");
            return;
        }

        Ticket ticket = new Ticket(movies[choice - 1], price);
        ticket.printTicket();
    }
}