public record Post(String id, String kind, String title, String text,
                   String media, String mediaType, long created) {
}