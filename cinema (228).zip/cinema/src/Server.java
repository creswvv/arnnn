import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Server {

    // ИЗМЕНИТЕ ПАРОЛЬ!
    static final String ADMIN_PASSWORD = "admin123";
    static final long MAX_UPLOAD = 200L * 1024 * 1024; // 200 МБ

    final Cinema cinema = new Cinema();
    final Store store = new Store();
    final Set<String> sessions = ConcurrentHashMap.newKeySet();
    final Path uploads = Paths.get("data", "uploads");

    static final String[] GRADIENTS = {
            "#0b3d91,#00c2c7", "#0d0d0d,#6a4c93", "#b00020,#1e3a8a", "#ff6f00,#212121"
    };

    public void start(int port) throws IOException {
        Files.createDirectories(uploads);
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/", this::route);
        server.start();
        System.out.println("Сайт: http://localhost:" + port);
        System.out.println("Админка: http://localhost:" + port + "/admin");
    }

    // ---------- маршруты ----------

    void route(HttpExchange ex) throws IOException {
        try {
            String path = ex.getRequestURI().getPath();
            String method = ex.getRequestMethod();

            if (path.equals("/")) html(ex, home());
            else if (path.equals("/buy")) html(ex, buy(ex));
            else if (path.startsWith("/uploads/")) serveFile(ex, path.substring("/uploads/".length()));
            else if (path.equals("/admin")) html(ex, admin(ex));
            else if (path.equals("/login") && method.equals("POST")) login(ex);
            else if (path.equals("/logout")) logout(ex);
            else if (path.equals("/admin/post") && method.equals("POST")) addPost(ex);
            else if (path.equals("/admin/delete") && method.equals("POST")) deletePost(ex);
            else send(ex, 404, "text/plain; charset=utf-8", "Не найдено".getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            e.printStackTrace();
            send(ex, 500, "text/plain; charset=utf-8", "Ошибка сервера".getBytes(StandardCharsets.UTF_8));
        }
    }

    // ---------- публичные страницы ----------

    String home() {
        List<Post> posts = store.all();
        Post ad = null;
        for (Post p : posts) {
            if (p.kind().equals("ad")) {
                ad = p;
                break;
            }
        }

        StringBuilder sb = new StringBuilder();
        sb.append("<header><div class='logo'>Кино<b>театр</b></div><a class='btn g' href='/admin'>Личный кабинет</a></header>");

        // рекламный баннер
        sb.append("<section class='promo'>");
        if (ad != null) {
            if (!ad.media().isEmpty()) {
                if (ad.mediaType().equals("video"))
                    sb.append("<video src='").append(esc(ad.media())).append("' autoplay muted loop playsinline></video>");
                else
                    sb.append("<img class='bg' src='").append(esc(ad.media())).append("' alt=''>");
            }
            sb.append("<div class='shade'></div><div class='in'><span class='tag'>РЕКЛАМА</span><h2>")
                    .append(esc(ad.title())).append("</h2><p>").append(esc(ad.text()))
                    .append("</p><a class='btn' href='#movies'>Купить билет</a></div>");
        } else {
            sb.append("<div class='shade'></div><div class='in'><span class='tag'>СКОРО В КИНО</span>")
                    .append("<h2>Большое кино — только у нас</h2><p>Выбирайте фильм и покупайте билет онлайн.</p>")
                    .append("<a class='btn' href='#movies'>Смотреть афишу</a></div>");
        }
        sb.append("</section>");

        // афиша
        sb.append("<h3>Афиша</h3><div class='grid' id='movies'>");
        String[] movies = cinema.getMovies();
        for (int i = 0; i < movies.length; i++) {
            sb.append("<div class='mv'><div class='po' style='background:linear-gradient(135deg,")
                    .append(GRADIENTS[i % GRADIENTS.length]).append(")'>").append(esc(movies[i]))
                    .append("</div><div class='bd'><small>").append(cinema.getPrice())
                    .append(" KZT</small><a class='btn' href='/buy?i=").append(i)
                    .append("'>Купить билет</a></div></div>");
        }
        sb.append("</div>");

        // лента статей, фото и видео
        sb.append("<h3>Новости и статьи</h3>");
        boolean any = false;
        for (Post p : posts) {
            if (p.kind().equals("ad")) continue;
            any = true;
            sb.append("<article class='post'>");
            if (!p.media().isEmpty()) {
                if (p.mediaType().equals("video"))
                    sb.append("<video class='m' src='").append(esc(p.media())).append("' controls preload='metadata'></video>");
                else
                    sb.append("<img class='m' src='").append(esc(p.media())).append("' alt=''>");
            }
            sb.append("<div class='c'><h4>").append(esc(p.title())).append("</h4><p class='t'>")
                    .append(esc(p.text())).append("</p><div class='d'>")
                    .append(new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm").format(new java.util.Date(p.created())))
                    .append("</div></div></article>");
        }
        if (!any) sb.append("<p class='mut'>Пока нет публикаций.</p>");

        return page("Кинотеатр", sb.toString());
    }

    String buy(HttpExchange ex) {
        String q = ex.getRequestURI().getQuery();
        int i = -1;
        try {
            i = Integer.parseInt(q.substring(q.indexOf("i=") + 2).split("&")[0]);
        } catch (Exception ignored) {
        }
        String[] movies = cinema.getMovies();
        if (i < 0 || i >= movies.length)
            return page("Билет", "<p>Фильм не найден!</p><a class='btn' href='/'>На главную</a>");

        Ticket t = new Ticket(movies[i], cinema.getPrice());
        return page("Ваш билет",
                "<h3>Ваш билет</h3><div class='tk'><div><b>Фильм:</b> " + esc(t.movieName)
                        + "</div><div><b>Цена:</b> " + t.price + " KZT</div>"
                        + "<div><b>Статус:</b> Билет успешно куплен!</div></div>"
                        + "<a class='btn' href='/'>На главную</a>");
    }

    // ---------- админка ----------

    boolean isAdmin(HttpExchange ex) {
        String cookie = ex.getRequestHeaders().getFirst("Cookie");
        if (cookie == null) return false;
        for (String part : cookie.split(";")) {
            part = part.trim();
            if (part.startsWith("sid=") && sessions.contains(part.substring(4))) return true;
        }
        return false;
    }

    String admin(HttpExchange ex) {
        if (!isAdmin(ex)) {
            return page("Вход",
                    "<h3>Вход в личный кабинет</h3><form method='post' action='/login'>"
                            + "<label>Пароль</label><input type='password' name='password' autofocus>"
                            + "<p><button>Войти</button> <a class='btn g' href='/'>На сайт</a></p></form>");
        }

        StringBuilder sb = new StringBuilder();
        sb.append("<header><div class='logo'>Личный <b>кабинет</b></div><div>")
                .append("<a class='btn g' href='/'>На сайт</a> <a class='btn g' href='/logout'>Выйти</a></div></header>");
        sb.append("<form method='post' action='/admin/post' enctype='multipart/form-data' class='card'>")
                .append("<h3 style='margin-top:0'>Новая публикация</h3>")
                .append("<label>Тип</label><select name='kind'>")
                .append("<option value='article'>Статья</option>")
                .append("<option value='photo'>Фото</option>")
                .append("<option value='video'>Видео</option>")
                .append("<option value='ad'>Рекламный пост (баннер на главной)</option></select>")
                .append("<label>Заголовок</label><input name='title' required>")
                .append("<label>Текст</label><textarea name='text'></textarea>")
                .append("<label>Фото или видео (jpg, png, gif, webp, mp4, webm, mov)</label>")
                .append("<input type='file' name='file' accept='image/*,video/*'>")
                .append("<p><button>Опубликовать</button></p></form>");

        sb.append("<h3>Опубликовано</h3>");
        List<Post> posts = store.all();
        if (posts.isEmpty()) sb.append("<p class='mut'>Пусто</p>");
        for (Post p : posts) {
            sb.append("<form method='post' action='/admin/delete' class='row' onsubmit=\"return confirm('Удалить?')\">")
                    .append("<span>[").append(esc(p.kind())).append("] ").append(esc(p.title())).append("</span>")
                    .append("<input type='hidden' name='id' value='").append(esc(p.id())).append("'>")
                    .append("<button class='x'>Удалить</button></form>");
        }
        return page("Личный кабинет", sb.toString());
    }

    void login(HttpExchange ex) throws IOException {
        Map<String, String> form = parseForm(new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
        if (ADMIN_PASSWORD.equals(form.get("password"))) {
            String sid = UUID.randomUUID().toString();
            sessions.add(sid);
            ex.getResponseHeaders().add("Set-Cookie", "sid=" + sid + "; Path=/; HttpOnly; SameSite=Lax");
        }
        redirect(ex, "/admin");
    }

    void logout(HttpExchange ex) throws IOException {
        String cookie = ex.getRequestHeaders().getFirst("Cookie");
        if (cookie != null) {
            for (String part : cookie.split(";")) {
                part = part.trim();
                if (part.startsWith("sid=")) sessions.remove(part.substring(4));
            }
        }
        redirect(ex, "/");
    }

    void addPost(HttpExchange ex) throws IOException {
        if (!isAdmin(ex)) {
            redirect(ex, "/admin");
            return;
        }
        String len = ex.getRequestHeaders().getFirst("Content-Length");
        if (len != null && Long.parseLong(len) > MAX_UPLOAD) {
            send(ex, 413, "text/plain; charset=utf-8", "Файл слишком большой".getBytes(StandardCharsets.UTF_8));
            return;
        }

        String ct = ex.getRequestHeaders().getFirst("Content-Type");
        Matcher bm = Pattern.compile("boundary=(?:\"([^\"]+)\"|([^;]+))").matcher(ct == null ? "" : ct);
        if (!bm.find()) {
            redirect(ex, "/admin");
            return;
        }
        String boundary = bm.group(1) != null ? bm.group(1) : bm.group(2);

        byte[] body = ex.getRequestBody().readAllBytes();
        Map<String, Part> parts = parseMultipart(body, boundary);

        String kind = text(parts, "kind");
        String title = text(parts, "title").trim();
        String content = text(parts, "text");
        if (title.isEmpty()) {
            redirect(ex, "/admin");
            return;
        }
        if (!Set.of("article", "photo", "video", "ad").contains(kind)) kind = "article";

        String media = "";
        String mediaType = "";
        Part file = parts.get("file");
        if (file != null && file.filename != null && !file.filename.isEmpty() && file.data.length > 0) {
            String name = file.filename.toLowerCase();
            String ext = name.contains(".") ? name.substring(name.lastIndexOf('.') + 1) : "";
            if (Set.of("mp4", "webm", "mov").contains(ext)) mediaType = "video";
            else if (Set.of("jpg", "jpeg", "png", "gif", "webp").contains(ext)) mediaType = "image";
            if (!mediaType.isEmpty()) {
                String stored = UUID.randomUUID() + "." + ext;
                Files.write(uploads.resolve(stored), file.data);
                media = "/uploads/" + stored;
            }
        }

        store.add(new Post(UUID.randomUUID().toString(), kind, title, content,
                media, mediaType, System.currentTimeMillis()));
        redirect(ex, "/admin");
    }

    void deletePost(HttpExchange ex) throws IOException {
        if (!isAdmin(ex)) {
            redirect(ex, "/admin");
            return;
        }
        Map<String, String> form = parseForm(new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
        Post removed = store.delete(form.getOrDefault("id", ""));
        if (removed != null && !removed.media().isEmpty()) {
            Files.deleteIfExists(uploads.resolve(Paths.get(removed.media()).getFileName().toString()));
        }
        redirect(ex, "/admin");
    }

    // ---------- файлы ----------

    void serveFile(HttpExchange ex, String name) throws IOException {
        Path f = uploads.resolve(Paths.get(name).getFileName().toString());
        if (!Files.exists(f)) {
            send(ex, 404, "text/plain", "Not found".getBytes());
            return;
        }
        String n = f.getFileName().toString().toLowerCase();
        String type = "application/octet-stream";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) type = "image/jpeg";
        else if (n.endsWith(".png")) type = "image/png";
        else if (n.endsWith(".gif")) type = "image/gif";
        else if (n.endsWith(".webp")) type = "image/webp";
        else if (n.endsWith(".mp4")) type = "video/mp4";
        else if (n.endsWith(".webm")) type = "video/webm";
        else if (n.endsWith(".mov")) type = "video/quicktime";
        send(ex, 200, type, Files.readAllBytes(f));
    }

    // ---------- multipart ----------

    static class Part {
        String filename;
        byte[] data;
    }

    static Map<String, Part> parseMultipart(byte[] body, String boundary) {
        Map<String, Part> result = new HashMap<>();
        byte[] delim = ("--" + boundary).getBytes(StandardCharsets.ISO_8859_1);
        byte[] headerEnd = "\r\n\r\n".getBytes(StandardCharsets.ISO_8859_1);
        Pattern namePat = Pattern.compile("name=\"([^\"]*)\"");
        Pattern filePat = Pattern.compile("filename=\"([^\"]*)\"");

        int pos = indexOf(body, delim, 0);
        while (pos >= 0) {
            int start = pos + delim.length;
            if (start + 1 < body.length && body[start] == '-' && body[start + 1] == '-') break;
            start += 2; // CRLF после boundary
            int next = indexOf(body, delim, start);
            if (next < 0) break;

            int hEnd = indexOf(body, headerEnd, start);
            if (hEnd >= 0 && hEnd < next) {
                String headers = new String(body, start, hEnd - start, StandardCharsets.UTF_8);
                int dataStart = hEnd + headerEnd.length;
                int dataEnd = next - 2; // убрать CRLF перед boundary
                Matcher nm = namePat.matcher(headers);
                if (nm.find() && dataEnd >= dataStart) {
                    Part p = new Part();
                    Matcher fm = filePat.matcher(headers);
                    if (fm.find()) p.filename = fm.group(1);
                    p.data = java.util.Arrays.copyOfRange(body, dataStart, dataEnd);
                    result.put(nm.group(1), p);
                }
            }
            pos = next;
        }
        return result;
    }

    static int indexOf(byte[] hay, byte[] needle, int from) {
        outer:
        for (int i = from; i <= hay.length - needle.length; i++) {
            for (int j = 0; j < needle.length; j++) {
                if (hay[i + j] != needle[j]) continue outer;
            }
            return i;
        }
        return -1;
    }

    static String text(Map<String, Part> parts, String name) {
        Part p = parts.get(name);
        return p == null ? "" : new String(p.data, StandardCharsets.UTF_8);
    }

    // ---------- утилиты ----------

    static Map<String, String> parseForm(String body) {
        Map<String, String> map = new HashMap<>();
        for (String pair : body.split("&")) {
            int eq = pair.indexOf('=');
            if (eq < 0) continue;
            map.put(URLDecoder.decode(pair.substring(0, eq), StandardCharsets.UTF_8),
                    URLDecoder.decode(pair.substring(eq + 1), StandardCharsets.UTF_8));
        }
        return map;
    }

    static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    void redirect(HttpExchange ex, String to) throws IOException {
        ex.getResponseHeaders().set("Location", to);
        ex.sendResponseHeaders(303, -1);
        ex.close();
    }

    void html(HttpExchange ex, String body) throws IOException {
        send(ex, 200, "text/html; charset=utf-8", body.getBytes(StandardCharsets.UTF_8));
    }

    void send(HttpExchange ex, int code, String type, byte[] bytes) throws IOException {
        ex.getResponseHeaders().set("Content-Type", type);
        ex.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    static final String CSS = """
            :root{--bg:#fff;--bg2:#f3f3f6;--tx:#17171c;--mut:#6b6b78;--ac:#e50914;--card:#fff;--bd:#e2e2ea}
            @media (prefers-color-scheme:dark){:root{--bg:#0e0e12;--bg2:#17171d;--tx:#f2f2f5;--mut:#9a9aa8;--card:#1b1b22;--bd:#2c2c36;color-scheme:dark}}
            *{box-sizing:border-box}
            body{margin:0;background:var(--bg);color:var(--tx);font:16px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
            .w{max-width:1000px;margin:0 auto;padding:0 16px 40px}
            header{display:flex;align-items:center;justify-content:space-between;padding:14px 0}
            .logo{font-weight:800;font-size:20px}.logo b{color:var(--ac)}
            .btn,button{display:inline-block;font:inherit;cursor:pointer;border:0;border-radius:10px;padding:10px 16px;background:var(--ac);color:#fff;font-weight:600;text-decoration:none}
            .btn.g{background:var(--bg2);color:var(--tx);border:1px solid var(--bd)}
            .promo{position:relative;border-radius:18px;overflow:hidden;min-height:300px;display:flex;align-items:flex-end;background:linear-gradient(135deg,#1a0b2e,#7b1fa2 55%,#e50914);color:#fff}
            .promo video,.promo img.bg{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
            .shade{position:absolute;inset:0;background:linear-gradient(0deg,rgba(0,0,0,.85),rgba(0,0,0,.05) 70%)}
            .in{position:relative;padding:24px;max-width:640px}
            .tag{display:inline-block;font-size:11px;letter-spacing:.08em;font-weight:700;border:1px solid rgba(255,255,255,.7);border-radius:6px;padding:2px 8px;margin-bottom:10px}
            .promo h2{margin:0 0 8px;font-size:clamp(24px,5vw,38px);line-height:1.1}
            .promo p{margin:0 0 14px;white-space:pre-wrap}
            h3{margin:32px 0 14px;font-size:22px}
            .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:14px}
            .mv{border-radius:14px;overflow:hidden;background:var(--card);border:1px solid var(--bd)}
            .po{height:150px;display:flex;align-items:flex-end;padding:12px;color:#fff;font-weight:800;font-size:20px}
            .bd{padding:12px;display:flex;justify-content:space-between;align-items:center;gap:8px}
            small,.mut,.d{color:var(--mut)}
            .post{background:var(--card);border:1px solid var(--bd);border-radius:14px;overflow:hidden;margin-bottom:14px}
            .post .m{width:100%;max-height:420px;object-fit:cover;display:block;background:#000}
            .c{padding:16px}.c h4{margin:0 0 6px;font-size:19px}.t{white-space:pre-wrap;margin:0}.d{font-size:13px;margin-top:8px}
            .tk{border:2px dashed var(--ac);border-radius:12px;padding:16px;margin:12px 0;max-width:420px}
            .card{background:var(--card);border:1px solid var(--bd);border-radius:14px;padding:18px}
            label{display:block;font-size:13px;color:var(--mut);margin:12px 0 4px}
            input,select,textarea{width:100%;font:inherit;padding:10px;border-radius:10px;border:1px solid var(--bd);background:var(--bg);color:var(--tx)}
            textarea{min-height:120px;resize:vertical}
            .row{display:flex;gap:8px;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--bd)}
            .x{background:transparent;color:var(--ac);padding:4px 8px}
            """;

    static String page(String title, String body) {
        return "<!DOCTYPE html><html lang='ru'><head><meta charset='utf-8'>"
                + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<title>" + esc(title) + "</title><style>" + CSS + "</style></head><body><div class='w'>"
                + body + "</div></body></html>";
    }
}