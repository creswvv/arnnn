import java.util.Scanner;

public class Menu {

    Scanner scanner = new Scanner(System.in);

    public void showMenu() {

        DecisionSystem decision = new DecisionSystem();

        int choice;

        do {
            System.out.println("\n===== КИНОТЕАТР =====");
            System.out.println("1. Посмотреть фильмы");
            System.out.println("2. Купить билет");
            System.out.println("3. Посмотреть стоимость билета");
            System.out.println("0. Выход");

            System.out.print("Выберите действие: ");

            choice = scanner.nextInt();

            decision.makeDecision(choice);

        } while (choice != 0);
    }
}