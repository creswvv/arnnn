
public class Ticket {

    String movieName;
    int price;

    public Ticket(String movieName, int price) {
        this.movieName = movieName;
        this.price = price;
    }

    public void printTicket() {

        System.out.println("\n===== YOUR TICKET =====");
        System.out.println("Movie: " + movieName);
        System.out.println("Price: " + price + " KZT");
        System.out.println("Status: Successfully purchased!");
        System.out.println("=======================");
    }
}
