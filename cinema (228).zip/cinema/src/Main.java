public class Main {
    public static void main(String[] args) throws Exception {
        new Server().start(8090);
    }
}